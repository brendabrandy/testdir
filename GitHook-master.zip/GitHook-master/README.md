## GitHook

## Sample usage

## Setup

Place the zip folder in the .git folder of your local repository

`cd .git/GitHook-master`

`bash install/install.sh`
